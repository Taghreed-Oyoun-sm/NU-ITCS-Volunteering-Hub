# backend/db_connection.py

import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

from dotenv import load_dotenv
load_dotenv()

# ---------------------------
# DATABASE URL
# ---------------------------

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "mysql+pymysql://root:Aw2p2df23_dz!io@localhost:3306/NU_Volunteering_Hub_DB"
)

# Detect if SSL is required
if "ssl=true" in DATABASE_URL.lower():
   
    DATABASE_URL = DATABASE_URL.replace("?ssl=true", "")
    connect_args = {"ssl": {}}  # default SSL
else:
    connect_args = {}

# ---------------------------
# ENGINE & SESSION
# ---------------------------
engine = create_engine(
    DATABASE_URL,
    echo=True,
    future=True,
    connect_args=connect_args  

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# ---------------------------
# BASE for models
# ---------------------------
Base = declarative_base()

# ---------------------------
# Dependency for FastAPI
# ---------------------------
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
